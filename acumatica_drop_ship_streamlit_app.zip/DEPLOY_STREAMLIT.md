# Acumatica Drop-Ship Converter — Streamlit Deployment

## Recommended setup

Put these files in one GitHub repository:

- streamlit_app.py
- requirements.txt

Then deploy the repository through Streamlit Community Cloud.

## Local test

Install:
    pip install -r requirements.txt

Run:
    streamlit run streamlit_app.py

## User experience

Users do NOT need Python installed when the app is deployed.
They open the web address, upload their vendor file, enter Vendor ID
only when needed, click the conversion button, review the results,
and download the Excel file.

## Important business/security consideration

For company use, confirm with your IT/security team whether vendor
files are permitted to be uploaded to an external cloud service.
If not, deploy the same Streamlit app inside an organization-controlled
environment (for example, an approved internal server/cloud platform).

## GitHub repository

The simplest deployment path is:
1. Create a private GitHub repository if company policy allows it.
2. Add streamlit_app.py and requirements.txt.
3. Connect GitHub to Streamlit Community Cloud.
4. Deploy streamlit_app.py.
5. Share the resulting app URL with authorized users.

Do not put credentials, API keys, or sensitive configuration into the
Python source code or GitHub repository.
